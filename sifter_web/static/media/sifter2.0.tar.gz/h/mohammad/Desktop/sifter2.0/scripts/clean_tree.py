from Bio import Phylo

familylist = []

# read in list of Pfam IDs                                                                             
infpf = open("pfamids2.txt", 'r')
for line in infpf:
    familylist.extend(line.strip().split())
infpf.close()

familylist = ['PF00685']
for fam in familylist:
    inf = open(fam+".nex", 'r')
    outf = open(fam+".nhx", 'w')
    for line in inf:
        d = line.strip().split(',')
        newline = ''
        for di in d:
            #print di
            if len(newline) > 0:
                outf.write(newline+',')
            while '/' in di:
                di = di[0:di.find('/')]+di[di.find(':'):]
            spe = di[(di.find("_")+1):di.find(":")]
            if ')' in di:
                direst = di[(di.find(")")+1):]
                di = di[0:di.find(")")]+"[&&NHX:S="+spe+"])"
                while ')' in direst:
                    di = di+direst[direst.find(":"):direst.find(")")]+"[&&NHX:D=N])"
                    direst = direst[(direst.find(")")+1):]
                di = di+direst[direst.find(":"):]+"[&&NHX:D=N]"
            else:
                di = di+"[&&NHX:S="+spe+"]"
            newline = di
        outf.write(newline[0:newline.find(";")]+";\n")
    inf.close()
    outf.close()
    print fam
