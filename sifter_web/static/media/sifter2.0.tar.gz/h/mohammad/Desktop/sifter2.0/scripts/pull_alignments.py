####
#

import os

# family names -> list of uniprot proteins
families = {}
familylist = []
# uniprot ids -> list of GOA annotations annotations
uniprots = {}
experimental = ['TAS', 'IDA', 'IMP']


# read in list of Pfam IDs
infpf = open("hundred.txt", 'r')
for line in infpf:
    familylist.extend(line.strip().split())

print familylist
familylist = ['PF00685']
# load families + uniprots (keys only)
infpf = open("../db/Pfam-A.full", 'r')
count = 0
outf = open("temp.fasta", 'w')
currentPfamily = ''
printout = False
for line in infpf:
    if line[0] == '#':
        if '#=GF AC' in line:
            pfamily = line[line.find('PF'):line.find('.')]
            print pfamily
            if pfamily in familylist:
                outf.close()
                outf = open(pfamily+".stockholm", 'w')
                outf.write("# STOCKHOLM 1.0\n")
                outf.write("#=GF ID   "+pfamily+"\n")
                printout = True
    if line[0:2] == '//':
        printout = False
    if printout:
        outf.write(line)
outf.close()

for fam in familylist:
    os.system("convalign FASTA "+fam+".stockholm")
    os.system("./FastTree "+fam+".fasta >"+fam+".nex")
