import os

# family names -> list of uniprot proteins
families = {}
familylist = []
# uniprot ids -> list of GOA annotations annotations
uniprots = {}
experimental = ['TAS', 'IDA', 'IMP']


# read in list of Pfam IDs
infpf = open("pfamids2.txt", 'r')
for line in infpf:
    familylist.extend(line.strip().split())
infpf.close()

print familylist

for fam in familylist:
    print " converting alignment: convalign FASTA "+fam+".stockholm"
    os.system("convalign FASTA "+fam+".stockholm")
    print " building tree "+fam
    os.system("./FastTree "+fam+".fasta >"+fam+".nex")
