
import os

path = "/Users/engelhardt/work/Berkeley/sifter/scripts/"

familylist = []
infpf = open(path+"pfamhundred2.txt", 'r')
#infpf = open("test.txt", 'r')
for line in infpf:
    familylist.extend(line.strip().split())
infpf.close()

for fam in familylist:
    print "Running sifter with domain "+fam
#run first sifter generate                                                                    
    os.system("java -jar sifter.jar "+fam+" --protein "+path+fam+".pli --reconciled "+path+fam+".nhx --with-tas -v --generate");
    
    os.system("mv infer-"+fam.lower()+".fx data/.;")
    os.system("mv scale-"+fam.lower()+".fx data/.;")
    os.system("mv alpha-"+fam.lower()+".fx data/.;")

#determine number of candidate functions                                                      
    #alpha = open("data/infer-"+fam.lower()+".fx",'r')
    alpha = open("data/alpha-"+fam.lower()+".fx",'r')
    cand_fns = 0
    for a in alpha:
        cand_fns = cand_fns + 1
    alpha.close()
    print "Found "+str(cand_fns)+" candidate functions!"

    if cand_fns < 2:
        print "\n\n**********TOO few candidate functions for "+fam+": remove from set!\n\n"
    if cand_fns < 8:
        print "RUNNING: java -jar sifter.jar "+fam+" --protein "+path+fam+".pli --reconciled "+path+fam+".nhx --with-tas --xvalidation -v > "+fam+"-sifterout.txt"
        os.system("java -jar sifter.jar "+fam+" --protein "+path+fam+".pli --reconciled "+path+fam+".nhx --with-tas --truncation "+str(cand_fns)+" --folds 0 --xvalidation -v > "+fam+"-sifterout.txt")
        os.system("mv output/default.rdata output/"+fam+".rdata;")
    else:
        print "\n\n**********TOO many candidate functions for "+fam+": remove from set!\n\n"
    
