species	0.19404
duplication	0.0796
